package ar.org.centro8.curso;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.entities.Alumno;
import ar.org.centro8.curso.entities.Curso;
import ar.org.centro8.curso.repositories.AlumnoRepository;
import ar.org.centro8.curso.repositories.CursoRepository;

@Service
@Controller
public class WebController {
    
    @Autowired
    private CursoRepository cursoRepository;

    @Autowired
    private AlumnoRepository alumnoRepository;

    private String mensajeCursos="Ingrese un nuevo curso!";
    private String mensajeAlumnos="Ingrese un nuevo alumno!";

    // para encender el server
    // desde una terminal bash o gitbash sh mvnw spring-boot:run
    // ir a la url localhost:8080

    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

    @GetMapping("/cursos")
    public String getCursos(@RequestParam(name="buscarTitulo", defaultValue = "", required = false) String buscarTitulo, Model model){
        model.addAttribute("curso", new Curso());
        model.addAttribute("mensajeCursos", mensajeCursos);
        //model.addAttribute("all", (List<Curso>)cursoRepository.findAll());
        model.addAttribute("likeTitulo", 
                (List<Curso>)cursoRepository.findByTituloContainingIgnoreCase(buscarTitulo));
        return "cursos";
    }

    @GetMapping("/alumnos")
    public String getAlumnos(@RequestParam(name="buscarApellido", defaultValue = "", required = false) String buscarApellido, Model model){
        Alumno alumno=new Alumno();
        alumno.setEdad(18);
        model.addAttribute("alumno", alumno);
        model.addAttribute("mensajeAlumnos", mensajeAlumnos);
        model.addAttribute("cursos", cursoRepository.findAll());
        model.addAttribute("likeApellido", 
                ((List<Alumno>)alumnoRepository.findByApellidoContainingIgnoreCase(buscarApellido)));
        return "alumnos";
    }

    @PostMapping("/saveCurso")
    public String saveCurso(@ModelAttribute Curso curso){
        System.out.println("******************************************");
        System.out.println(curso);
        System.out.println("******************************************");
        try {
            cursoRepository.save(curso);
            mensajeCursos="Se ingreso un nuevo curso id: "+curso.getId();
        } catch (Exception e) {
            mensajeCursos="Ocurrio un error";
            System.out.println("******************************************");
            System.out.println(e);
            System.out.println("******************************************");
        }
        return "redirect:cursos";
    }

    @PostMapping("/saveAlumno")
    public String saveAlumno(@ModelAttribute Alumno alumno){
        System.out.println("******************************************");
        System.out.println(alumno);
        System.out.println("******************************************");
        try {
            alumnoRepository.save(alumno);
            mensajeAlumnos="Se ingreso un nuevo alumno id: "+alumno.getId();
        } catch (Exception e) {
            mensajeAlumnos="Ocurrio un error";
            System.out.println("******************************************");
            System.out.println(e);
            System.out.println("******************************************");
        }
        return "redirect:alumnos";
    }

    @GetMapping("/removeCurso")
    public String removeCurso(@RequestParam(name="idBorrar", defaultValue = "0", required = false) int idBorrar, Model model){
        //System.out.println("******************************************");
        //System.out.println(idBorrar);
        //System.out.println("******************************************");
        long cantidadAlumnos=((List<Alumno>)alumnoRepository
                                                .findAll())
                                                .stream()
                                                .filter(alumno->alumno.getIdCurso()==idBorrar)
                                                .count();
        //System.out.println("******************************************");
        //System.out.println(cantidadAlumnos);
        //System.out.println("******************************************");
        if(cantidadAlumnos==0)
            cursoRepository.delete(cursoRepository.findById(idBorrar).get());
        else
            mensajeCursos="No se puede borrar el cursos, por que tiene alumnos inscriptos!";
        return "redirect:cursos";
    }

    @GetMapping("/removeAlumno")
    public String removeAlumno(@RequestParam(name="idBorrar", defaultValue = "0", required = false) 
        int idBorrar, Model model){
        alumnoRepository.delete(alumnoRepository.findById(idBorrar).get());
        return "redirect:alumnos";
    }

}
