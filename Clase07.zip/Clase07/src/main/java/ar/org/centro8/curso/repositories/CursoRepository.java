package ar.org.centro8.curso.repositories;

public class CursoRepository {
    
}
