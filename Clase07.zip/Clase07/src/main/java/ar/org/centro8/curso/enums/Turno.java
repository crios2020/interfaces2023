package ar.org.centro8.curso.enums;

public enum Turno {
    MAÑANA,
    TARDE,
    NOCHE
}
