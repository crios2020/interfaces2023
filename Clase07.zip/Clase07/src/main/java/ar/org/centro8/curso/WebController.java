package ar.org.centro8.curso;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import ar.org.centro8.curso.entities.Curso;
import ar.org.centro8.curso.repositories.AlumnoRepository;
import ar.org.centro8.curso.repositories.CursoRepository;

@Service
@Controller
public class WebController {
    
    @Autowired
    private CursoRepository cursoRepository;

    @Autowired
    private AlumnoRepository alumnoRepository;

    private String mensajeCursos="Ingrese un nuevo curso!";

    // para encender el server
    // desde una terminal bash o gitbash sh mvnw spring-boot:run
    // ir a la url localhost:8080

    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

    @GetMapping("/cursos")
    public String getCursos(Model model){
        model.addAttribute("curso", new Curso());
        model.addAttribute("mensajeCursos", mensajeCursos);
        return "cursos";
    }

    @GetMapping("/alumnos")
    public String getAlumnos(){
        return "alumnos";
    }

    @PostMapping("/save")
    public String save(@ModelAttribute Curso curso){
        System.out.println("******************************************");
        System.out.println(curso);
        System.out.println("******************************************");
        try {
            cursoRepository.save(curso);
            mensajeCursos="Se ingreso un nuevo curso id: "+curso.getId();
        } catch (Exception e) {
            mensajeCursos="Ocurrio un error";
            System.out.println("******************************************");
            System.out.println(e);
            System.out.println("******************************************");
        }
        return "redirect:cursos";
    }

}
