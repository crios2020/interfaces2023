package ar.org.centro8.curso;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {
    
    // para encender el server
    // desde una terminal bash o gitbash sh mvnw spring-boot:run
    // ir a la url localhost:8080

    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

    @GetMapping("/cursos")
    public String getCursos(){
        return "cursos";
    }

    @GetMapping("/alumnos")
    public String getAlumnos(){
        return "alumnos";
    }

}
