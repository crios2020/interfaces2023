package ar.org.centro8.curso.clase5;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {
    
    // para encender el server
    // desde una terminal bash o gitbash sh mvnw spring-boot:run
    // ir a la url localhost:8080

    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

}
